﻿
int[,,] array3DDeclaration = new int[3, 3, 3];

// initialized 3D Array
string[,,] simple3DArray =
{
    {
        {"000", "001"},
        {"010", "011" }
    },
    {
        {"100", "101"},
        {"110", "111"}
    },
    {
        {"200", "201"},
        {"210", "211"}
    }
};

// assign a value
simple3DArray[2, 1, 0] = "Hi, what's up?";

Console.WriteLine(simple3DArray[2,1,0]);


string[,] understandingIndexes =
{
    {"0,0","0,1","0,2" },
    {"1,0","1,1","1,2" },
    {"2,0","2,1","2,2" }
};


Console.ReadKey();



// Indexes [0][ 1][ 2][ 3][ 4]
// content [5][12][13][14][15]

