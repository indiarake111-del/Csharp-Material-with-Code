﻿
int num1 = 0;
int num2 = 0;
int num3 = 0;
int num4 = 0;
int num5 = 0;

// declare an array
int[] myIntArray = new int[5];

// assigned values to the array
myIntArray[0] = 5;
myIntArray[1] = 12;
myIntArray[2] = 13;
myIntArray[3] = 14;
myIntArray[4] = 15;

Console.WriteLine(myIntArray[3]);

Console.ReadKey();



// Indexes [0][ 1][ 2][ 3][ 4]
// content [5][12][13][14][15]

