﻿
int[,] array2DDeclaration = new int[3, 3];
// [0] [0] [0]
// [0] [0] [0]
// [0] [0] [0]

int[,,] array3DDeclaration = new int[3, 3, 3];


int[,] array2DInizilized = { {1,2}, {3,4} };
// [1] [2]  // row 0
// [3] [4]  // row 1

string[,] ticTacToeField =
{
    {"O","X","X" },
    {"O","O","X" },
    {"X","X","O" }
};

string[,] understandingIndexes =
{
    {"0,0","0,1","0,2" },
    {"1,0","1,1","1,2" },
    {"2,0","2,1","2,2" }
};

Console.WriteLine(understandingIndexes[1,2]);

Console.ReadKey();



// Indexes [0][ 1][ 2][ 3][ 4]
// content [5][12][13][14][15]

