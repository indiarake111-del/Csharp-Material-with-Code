﻿namespace ClassesApp
{
    internal class Program
    {
        static void Main(string[] args)
        {   
            // Creating an object of the Class Car
            // Creating an instance of the Class Car
            Car audi = new Car();
            Car bmw = new Car();

            Console.ReadKey();
        }
    }
}
