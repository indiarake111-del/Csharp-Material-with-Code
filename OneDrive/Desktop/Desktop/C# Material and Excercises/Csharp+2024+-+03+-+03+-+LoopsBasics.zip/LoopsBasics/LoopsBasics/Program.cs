﻿

for (int counter = 10; counter >= 0; counter--)
{
    Console.WriteLine("Counter is " + counter);
}


Console.ReadKey();

