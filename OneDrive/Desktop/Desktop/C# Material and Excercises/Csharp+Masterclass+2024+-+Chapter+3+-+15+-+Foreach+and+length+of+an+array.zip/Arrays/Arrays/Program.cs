﻿
int num1 = 0;
int num2 = 0;
int num3 = 0;
int num4 = 0;
int num5 = 0;

// declare an array and set the array element values
int[] myIntArray = [1,2,3,4,5];

string[] weekDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

Console.WriteLine("Lenght of the weekdays Array is: " + weekDays.Length);

//for (int i = 0; i < weekDays.Length; i++)
//{
//    Console.WriteLine(weekDays[i]);
//}

foreach (string day in weekDays)
{
    Console.WriteLine(day);
}


Console.ReadKey();



// Indexes [0][ 1][ 2][ 3][ 4]
// content [5][12][13][14][15]

